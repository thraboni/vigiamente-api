# Executando o projeto

- yarn install
- yarn run dev
- Olhe o package.json para ver os comandos que foram criados para start da aplicação
- No projeto tem um docker compose para usbir o postgre na sua máquina caso não queira instalar
